/* ============================================================
   STARFIELD — Fondo espacial animado (Canvas API)
   Genera: capas de estrellas con parallax, nebulosas difusas,
   estrellas fugaces periódicas y una constelación sutil.
   ============================================================ */

export function initStarfield(canvasId = 'space-canvas') {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  let width, height, dpr;
  let stars = [];
  let nebulas = [];
  let shootingStars = [];
  let constellationPoints = [];
  let pointer = { x: 0, y: 0 };
  let scrollY = 0;

  const STAR_LAYERS = [
    { count: 90, speed: 0.02, size: [0.4, 1.1], parallax: 0.02 },
    { count: 60, speed: 0.04, size: [0.8, 1.8], parallax: 0.05 },
    { count: 30, speed: 0.07, size: [1.4, 2.6], parallax: 0.09 },
  ];

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    buildScene();
  }

  function rand(min, max) { return Math.random() * (max - min) + min; }

  function buildScene() {
    stars = [];
    STAR_LAYERS.forEach((layer, layerIndex) => {
      for (let i = 0; i < layer.count; i++) {
        stars.push({
          x: rand(0, width),
          y: rand(0, height),
          r: rand(layer.size[0], layer.size[1]),
          twinklePhase: rand(0, Math.PI * 2),
          twinkleSpeed: rand(0.4, 1.2),
          layer: layerIndex,
          parallax: layer.parallax,
        });
      }
    });

    nebulas = [
      { x: width * 0.18, y: height * 0.25, r: Math.max(width, height) * 0.35, color: 'nebula-1' },
      { x: width * 0.85, y: height * 0.65, r: Math.max(width, height) * 0.4, color: 'nebula-2' },
      { x: width * 0.5, y: height * 0.85, r: Math.max(width, height) * 0.3, color: 'nebula-3' },
    ];

    // Constelación sutil y decorativa (puntos conectados aleatoriamente, sin significado narrativo aún)
    constellationPoints = [];
    const cx = width * 0.72, cy = height * 0.28, spread = Math.min(width, height) * 0.18;
    for (let i = 0; i < 6; i++) {
      constellationPoints.push({
        x: cx + rand(-spread, spread),
        y: cy + rand(-spread, spread),
      });
    }
  }

  function spawnShootingStar() {
    if (reduceMotion) return;
    shootingStars.push({
      x: rand(width * 0.1, width * 0.9),
      y: rand(0, height * 0.4),
      len: rand(80, 160),
      speed: rand(9, 15),
      angle: Math.PI / 4 + rand(-0.15, 0.15),
      life: 1,
    });
  }

  function scheduleShootingStar() {
    const delay = rand(4000, 9000);
    setTimeout(() => {
      spawnShootingStar();
      scheduleShootingStar();
    }, delay);
  }

  function drawNebulas(t) {
    const colorMap = {
      'nebula-1': '91, 47, 143',
      'nebula-2': '178, 63, 160',
      'nebula-3': '47, 79, 159',
    };
    nebulas.forEach((n, i) => {
      const drift = Math.sin(t * 0.00005 + i) * 20;
      const grad = ctx.createRadialGradient(
        n.x + drift, n.y - scrollY * 0.03, 0,
        n.x + drift, n.y - scrollY * 0.03, n.r
      );
      const c = colorMap[n.color];
      grad.addColorStop(0, `rgba(${c}, 0.28)`);
      grad.addColorStop(0.5, `rgba(${c}, 0.10)`);
      grad.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
    });
  }

  function drawStars(t) {
    stars.forEach(s => {
      const twinkle = reduceMotion ? 0.8 : 0.5 + 0.5 * Math.sin(t * 0.001 * s.twinkleSpeed + s.twinklePhase);
      const px = s.x + (pointer.x - width / 2) * s.parallax;
      const py = s.y + (pointer.y - height / 2) * s.parallax - scrollY * s.parallax * 0.6;
      ctx.beginPath();
      ctx.arc(px, ((py % height) + height) % height, s.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(246, 242, 255, ${twinkle})`;
      ctx.shadowColor = 'rgba(200,180,255,0.8)';
      ctx.shadowBlur = s.r * 2;
      ctx.fill();
    });
    ctx.shadowBlur = 0;
  }

  function drawConstellation(t) {
    ctx.save();
    ctx.strokeStyle = 'rgba(169,138,240,0.25)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    constellationPoints.forEach((p, i) => {
      const py = p.y - scrollY * 0.04;
      if (i === 0) ctx.moveTo(p.x, py); else ctx.lineTo(p.x, py);
    });
    ctx.stroke();
    constellationPoints.forEach(p => {
      const py = p.y - scrollY * 0.04;
      ctx.beginPath();
      ctx.arc(p.x, py, 2, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(230,220,255,0.9)';
      ctx.shadowColor = 'rgba(169,138,240,0.9)';
      ctx.shadowBlur = 8;
      ctx.fill();
    });
    ctx.restore();
  }

  function drawShootingStars() {
    shootingStars.forEach(s => {
      const dx = Math.cos(s.angle) * s.len;
      const dy = Math.sin(s.angle) * s.len;
      const grad = ctx.createLinearGradient(s.x, s.y, s.x - dx, s.y - dy);
      grad.addColorStop(0, `rgba(255,255,255,${s.life})`);
      grad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.strokeStyle = grad;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(s.x, s.y);
      ctx.lineTo(s.x - dx, s.y - dy);
      ctx.stroke();

      s.x += Math.cos(s.angle) * s.speed;
      s.y += Math.sin(s.angle) * s.speed;
      s.life -= 0.012;
    });
    shootingStars = shootingStars.filter(s => s.life > 0 && s.y < height + 50);
  }

  function loop(t) {
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = 'rgba(5,4,10,1)';
    ctx.fillRect(0, 0, width, height);
    drawNebulas(t);
    drawStars(t);
    drawConstellation(t);
    drawShootingStars();
    requestAnimationFrame(loop);
  }

  window.addEventListener('resize', resize);
  window.addEventListener('mousemove', e => { pointer.x = e.clientX; pointer.y = e.clientY; });
  window.addEventListener('scroll', () => { scrollY = window.scrollY; }, { passive: true });

  resize();
  requestAnimationFrame(loop);
  if (!reduceMotion) scheduleShootingStar();
}
