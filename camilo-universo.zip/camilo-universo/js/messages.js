/* ============================================================
   RANDOM MESSAGES — sistema de mensajes aleatorios vía JSON
   ============================================================ */

export class RandomMessages {
  constructor({ dataUrl, buttonId, cardId }) {
    this.dataUrl = dataUrl;
    this.button = document.getElementById(buttonId);
    this.card = document.getElementById(cardId);
    this.messages = [];
    this.lastIndex = -1;
  }

  async init() {
    try {
      const res = await fetch(this.dataUrl);
      const data = await res.json();
      this.messages = data.mensajes || [];
    } catch (err) {
      console.error('No se pudo cargar messages.json', err);
    }
    this.button?.addEventListener('click', () => this.showRandom());
  }

  showRandom() {
    if (!this.card || this.messages.length === 0) return;
    let index = Math.floor(Math.random() * this.messages.length);
    if (this.messages.length > 1 && index === this.lastIndex) {
      index = (index + 1) % this.messages.length;
    }
    this.lastIndex = index;
    const msg = this.messages[index];

    this.card.innerHTML = `
      <div class="icon">${msg.icono || '✨'}</div>
      <p>${this._escape(msg.texto)}</p>
    `;
    this.card.classList.remove('is-visible');
    // Reinicia la animación de aparición
    requestAnimationFrame(() => this.card.classList.add('is-visible'));
  }

  _escape(str = '') {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }
}
