/* ============================================================
   MODAL — controlador genérico reutilizable
   ============================================================ */

export function initModal({ triggerId, overlayId, closeSelector = '.modal-close' }) {
  const trigger = document.getElementById(triggerId);
  const overlay = document.getElementById(overlayId);
  if (!trigger || !overlay) return;

  function open() {
    overlay.classList.add('is-open');
    overlay.setAttribute('aria-hidden', 'false');
    const closeBtn = overlay.querySelector(closeSelector);
    closeBtn?.focus();
  }

  function close() {
    overlay.classList.remove('is-open');
    overlay.setAttribute('aria-hidden', 'true');
    trigger.focus();
  }

  trigger.addEventListener('click', open);
  overlay.querySelector(closeSelector)?.addEventListener('click', close);
  overlay.addEventListener('click', e => { if (e.target === overlay) close(); });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && overlay.classList.contains('is-open')) close();
  });
}
