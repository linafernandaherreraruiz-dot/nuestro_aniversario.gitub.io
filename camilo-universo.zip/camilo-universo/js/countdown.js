/* ============================================================
   COUNTDOWN — del 5 de julio de 2025 al 4 de julio de 2026
   ============================================================ */

export function initCountdown(rootId = 'countdown') {
  const root = document.getElementById(rootId);
  if (!root) return;

  const startDate = new Date('2025-07-05T00:00:00');
  const endDate = new Date('2026-07-04T23:59:59');

  const els = {
    days: root.querySelector('[data-unit="days"]'),
    hours: root.querySelector('[data-unit="hours"]'),
    minutes: root.querySelector('[data-unit="minutes"]'),
    seconds: root.querySelector('[data-unit="seconds"]'),
    label: root.querySelector('[data-countdown-label]'),
  };

  function tick() {
    const now = new Date();
    let diff = endDate - now;
    let label = 'Tiempo restante hasta el 4 de julio de 2026';

    if (now < startDate) {
      diff = startDate - now;
      label = 'Faltan para comenzar la cuenta (5 de julio de 2025)';
    } else if (diff <= 0) {
      diff = 0;
      label = '¡Fecha alcanzada! 4 de julio de 2026';
    }

    const totalSeconds = Math.floor(diff / 1000);
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    if (els.days) els.days.textContent = String(days).padStart(2, '0');
    if (els.hours) els.hours.textContent = String(hours).padStart(2, '0');
    if (els.minutes) els.minutes.textContent = String(minutes).padStart(2, '0');
    if (els.seconds) els.seconds.textContent = String(seconds).padStart(2, '0');
    if (els.label) els.label.textContent = label;
  }

  tick();
  setInterval(tick, 1000);
}
