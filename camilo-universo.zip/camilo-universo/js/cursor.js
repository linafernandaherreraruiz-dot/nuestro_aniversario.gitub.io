/* ============================================================
   CURSOR PERSONALIZADO
   ============================================================ */

export function initCustomCursor() {
  if (window.matchMedia('(hover: none)').matches) return; // dispositivos táctiles conservan el cursor nativo

  const cursor = document.createElement('div');
  cursor.id = 'custom-cursor';
  document.body.appendChild(cursor);

  let mouseX = 0, mouseY = 0;
  let curX = 0, curY = 0;

  window.addEventListener('mousemove', e => {
    mouseX = e.clientX;
    mouseY = e.clientY;
  });

  function animate() {
    // Suavizado (lerp) para un movimiento fluido y elegante
    curX += (mouseX - curX) * 0.2;
    curY += (mouseY - curY) * 0.2;
    cursor.style.transform = `translate(${curX}px, ${curY}px) translate(-50%, -50%)`;
    requestAnimationFrame(animate);
  }
  requestAnimationFrame(animate);

  const interactiveSelector = 'a, button, input[type="range"], [data-cursor-hover]';
  document.addEventListener('mouseover', e => {
    if (e.target.closest(interactiveSelector)) cursor.classList.add('is-hover');
  });
  document.addEventListener('mouseout', e => {
    if (e.target.closest(interactiveSelector)) cursor.classList.remove('is-hover');
  });
}
