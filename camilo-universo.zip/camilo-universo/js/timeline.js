/* ============================================================
   TIMELINE — renderiza hitos desde data/timeline.json
   ============================================================ */

export async function initTimeline(rootId = 'timeline-list', dataUrl = 'data/timeline.json') {
  const root = document.getElementById(rootId);
  if (!root) return;

  let hitos = [];
  try {
    const res = await fetch(dataUrl);
    const data = await res.json();
    hitos = data.hitos || [];
  } catch (err) {
    console.error('No se pudo cargar timeline.json', err);
  }

  if (hitos.length === 0) {
    root.innerHTML = '<p class="placeholder-note">La línea del tiempo está preparada y vacía. Los hitos se agregarán en la siguiente fase.</p>';
    return;
  }

  root.innerHTML = hitos.map(h => `
    <li class="timeline-item" data-reveal>
      <span class="date">${h.fecha || ''}</span>
      <h3>${h.titulo || ''}</h3>
      <p>${h.descripcion || ''}</p>
      ${h.imagen ? `<img src="${h.imagen}" alt="" loading="lazy">` : ''}
    </li>
  `).join('');
}
