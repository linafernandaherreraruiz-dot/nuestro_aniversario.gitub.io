/* ============================================================
   PETALS — Lluvia sutil de pétalos morados (Canvas API)
   ============================================================ */

export function initPetals(canvasId = 'petals-canvas') {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduceMotion) return; // respetamos la preferencia de movimiento reducido

  let width, height, dpr;
  let petals = [];
  const COUNT = 26;

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function rand(min, max) { return Math.random() * (max - min) + min; }

  function makePetal() {
    return {
      x: rand(0, width),
      y: rand(-height, 0),
      size: rand(6, 14),
      speedY: rand(0.4, 1.1),
      speedX: rand(-0.3, 0.3),
      rotation: rand(0, Math.PI * 2),
      rotationSpeed: rand(-0.01, 0.01),
      sway: rand(0.4, 1.4),
      swayOffset: rand(0, Math.PI * 2),
      opacity: rand(0.35, 0.75),
      hue: rand(270, 310), // gama de morados/magentas
    };
  }

  function initPetalArray() {
    petals = Array.from({ length: COUNT }, makePetal);
  }

  function drawPetal(p, t) {
    ctx.save();
    const swayX = Math.sin(t * 0.0006 * p.sway + p.swayOffset) * 18;
    ctx.translate(p.x + swayX, p.y);
    ctx.rotate(p.rotation);
    ctx.beginPath();
    ctx.ellipse(0, 0, p.size * 0.6, p.size, 0, 0, Math.PI * 2);
    ctx.fillStyle = `hsla(${p.hue}, 70%, 72%, ${p.opacity})`;
    ctx.shadowColor = `hsla(${p.hue}, 80%, 60%, 0.5)`;
    ctx.shadowBlur = 6;
    ctx.fill();
    ctx.restore();
  }

  function loop(t) {
    ctx.clearRect(0, 0, width, height);
    petals.forEach(p => {
      drawPetal(p, t);
      p.y += p.speedY;
      p.x += p.speedX;
      p.rotation += p.rotationSpeed;
      if (p.y > height + 20) {
        Object.assign(p, makePetal(), { y: -20 });
      }
    });
    requestAnimationFrame(loop);
  }

  window.addEventListener('resize', () => { resize(); });
  resize();
  initPetalArray();
  requestAnimationFrame(loop);
}
