/* ============================================================
   MUSIC PLAYER — reproductor profesional alimentado por playlist.json
   La música continúa sonando mientras el usuario navega la página
   (un solo elemento <audio> vive durante toda la sesión).
   ============================================================ */

export class MusicPlayer {
  constructor({ dataUrl, rootId, playlistListId }) {
    this.dataUrl = dataUrl;
    this.root = document.getElementById(rootId);
    this.playlistListEl = document.getElementById(playlistListId);
    this.audio = new Audio();
    this.audio.preload = 'metadata';

    this.songs = [];
    this.currentIndex = 0;
    this.isShuffle = false;
    this.repeatMode = 'none'; // 'none' | 'one' | 'all'
    this.shuffleOrder = [];

    this._bindElements();
    this._bindAudioEvents();
    this._bindControlEvents();
  }

  async init() {
    try {
      const res = await fetch(this.dataUrl);
      const data = await res.json();
      this.songs = data.canciones || [];
    } catch (err) {
      console.error('No se pudo cargar playlist.json', err);
      this.songs = [];
    }

    if (this.songs.length === 0) {
      this._renderEmptyState();
      return;
    }

    this._buildShuffleOrder();
    this._renderPlaylist();
    this._loadSong(0, { autoplay: false });
  }

  _bindElements() {
    if (!this.root) return;
    this.els = {
      cover: this.root.querySelector('.player-cover img'),
      title: this.root.querySelector('.player-title'),
      artist: this.root.querySelector('.player-artist'),
      playBtn: this.root.querySelector('.btn-play'),
      prevBtn: this.root.querySelector('.btn-prev'),
      nextBtn: this.root.querySelector('.btn-next'),
      shuffleBtn: this.root.querySelector('.btn-shuffle'),
      repeatBtn: this.root.querySelector('.btn-repeat'),
      progressBar: this.root.querySelector('.progress-range'),
      currentTime: this.root.querySelector('.current-time'),
      duration: this.root.querySelector('.duration-time'),
      volumeRange: this.root.querySelector('.volume-range'),
      toggleBtn: this.root.querySelector('.player-toggle'),
    };
  }

  _bindAudioEvents() {
    this.audio.addEventListener('timeupdate', () => this._updateProgress());
    this.audio.addEventListener('loadedmetadata', () => this._updateDuration());
    this.audio.addEventListener('ended', () => this._handleEnded());
    this.audio.addEventListener('play', () => this._setPlayIcon(true));
    this.audio.addEventListener('pause', () => this._setPlayIcon(false));
  }

  _bindControlEvents() {
    if (!this.root) return;
    this.els.playBtn?.addEventListener('click', () => this.togglePlay());
    this.els.prevBtn?.addEventListener('click', () => this.prev());
    this.els.nextBtn?.addEventListener('click', () => this.next());
    this.els.shuffleBtn?.addEventListener('click', () => this.toggleShuffle());
    this.els.repeatBtn?.addEventListener('click', () => this.cycleRepeat());
    this.els.progressBar?.addEventListener('input', e => this.seek(e.target.value));
    this.els.volumeRange?.addEventListener('input', e => this.setVolume(e.target.value));
    this.els.toggleBtn?.addEventListener('click', () => this.root.classList.toggle('is-collapsed'));

    // Volumen inicial
    this.audio.volume = 0.6;
  }

  _renderEmptyState() {
    if (this.playlistListEl) {
      this.playlistListEl.innerHTML =
        '<li class="placeholder-note">Aún no hay canciones. Copia archivos MP3/WAV/OGG en <code>assets/music/</code> y agrégalos en <code>data/playlist.json</code>.</li>';
    }
    if (this.els?.title) this.els.title.textContent = 'Sin canciones todavía';
    if (this.els?.artist) this.els.artist.textContent = 'Agrega música en assets/music/';
  }

  _renderPlaylist() {
    if (!this.playlistListEl) return;
    this.playlistListEl.innerHTML = '';
    this.songs.forEach((song, i) => {
      const li = document.createElement('li');
      li.className = 'playlist-item';
      li.setAttribute('data-index', i);
      li.setAttribute('tabindex', '0');
      li.innerHTML = `
        <span class="index">${String(i + 1).padStart(2, '0')}</span>
        <span class="cover-mini"><img src="${song.cover || 'assets/img/portada-default.svg'}" alt="" loading="lazy"></span>
        <span class="info">
          <span class="title">${this._escape(song.titulo)}</span>
          <span class="artist">${this._escape(song.artista)}</span>
        </span>
      `;
      li.addEventListener('click', () => this._loadSong(i, { autoplay: true }));
      this.playlistListEl.appendChild(li);
    });
  }

  _escape(str = '') {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  _buildShuffleOrder() {
    this.shuffleOrder = this.songs.map((_, i) => i);
    for (let i = this.shuffleOrder.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [this.shuffleOrder[i], this.shuffleOrder[j]] = [this.shuffleOrder[j], this.shuffleOrder[i]];
    }
  }

  _loadSong(index, { autoplay }) {
    if (!this.songs[index]) return;
    this.currentIndex = index;
    const song = this.songs[index];
    this.audio.src = song.src;
    if (this.els) {
      this.els.title.textContent = song.titulo || 'Sin título';
      this.els.artist.textContent = song.artista || 'Artista desconocido';
      this.els.cover.src = song.cover || 'assets/img/portada-default.svg';
    }
    this._highlightActive();
    if (autoplay) this.play();
  }

  _highlightActive() {
    this.playlistListEl?.querySelectorAll('.playlist-item').forEach(item => {
      item.classList.toggle('is-playing', Number(item.dataset.index) === this.currentIndex);
    });
  }

  play() {
    this.audio.play().catch(() => {
      /* la reproducción automática puede requerir interacción previa del usuario; se ignora silenciosamente */
    });
  }

  pause() { this.audio.pause(); }

  togglePlay() {
    if (this.audio.paused) this.play(); else this.pause();
  }

  _setPlayIcon(isPlaying) {
    if (!this.els?.playBtn) return;
    this.els.playBtn.innerHTML = isPlaying ? this._iconPause() : this._iconPlay();
    this.els.playBtn.setAttribute('aria-label', isPlaying ? 'Pausar' : 'Reproducir');
  }

  _iconPlay() { return '▶'; }
  _iconPause() { return '❚❚'; }

  next() {
    if (this.songs.length === 0) return;
    let nextIndex;
    if (this.isShuffle) {
      const pos = this.shuffleOrder.indexOf(this.currentIndex);
      nextIndex = this.shuffleOrder[(pos + 1) % this.shuffleOrder.length];
    } else {
      nextIndex = (this.currentIndex + 1) % this.songs.length;
    }
    this._loadSong(nextIndex, { autoplay: true });
  }

  prev() {
    if (this.songs.length === 0) return;
    let prevIndex;
    if (this.isShuffle) {
      const pos = this.shuffleOrder.indexOf(this.currentIndex);
      prevIndex = this.shuffleOrder[(pos - 1 + this.shuffleOrder.length) % this.shuffleOrder.length];
    } else {
      prevIndex = (this.currentIndex - 1 + this.songs.length) % this.songs.length;
    }
    this._loadSong(prevIndex, { autoplay: true });
  }

  toggleShuffle() {
    this.isShuffle = !this.isShuffle;
    this.els?.shuffleBtn?.classList.toggle('is-active', this.isShuffle);
    if (this.isShuffle) this._buildShuffleOrder();
  }

  cycleRepeat() {
    const modes = ['none', 'all', 'one'];
    const idx = modes.indexOf(this.repeatMode);
    this.repeatMode = modes[(idx + 1) % modes.length];
    this.els?.repeatBtn?.classList.toggle('is-active', this.repeatMode !== 'none');
    this.els?.repeatBtn?.setAttribute('data-mode', this.repeatMode);
  }

  _handleEnded() {
    if (this.repeatMode === 'one') {
      this.audio.currentTime = 0;
      this.play();
    } else if (this.repeatMode === 'none' && !this.isShuffle && this.currentIndex === this.songs.length - 1) {
      this._setPlayIcon(false); // fin de la playlist
    } else {
      this.next();
    }
  }

  seek(value) {
    if (!this.audio.duration) return;
    this.audio.currentTime = (value / 100) * this.audio.duration;
  }

  setVolume(value) {
    this.audio.volume = value / 100;
  }

  _updateProgress() {
    if (!this.els) return;
    const pct = this.audio.duration ? (this.audio.currentTime / this.audio.duration) * 100 : 0;
    if (this.els.progressBar) this.els.progressBar.value = pct;
    if (this.els.currentTime) this.els.currentTime.textContent = this._formatTime(this.audio.currentTime);
  }

  _updateDuration() {
    if (this.els?.duration) this.els.duration.textContent = this._formatTime(this.audio.duration);
  }

  _formatTime(sec) {
    if (!isFinite(sec)) return '0:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  }
}
