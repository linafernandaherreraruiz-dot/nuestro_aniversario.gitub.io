/* ============================================================
   MAIN — punto de entrada de la aplicación
   ============================================================ */
import { initStarfield } from './starfield.js';
import { initPetals } from './petals.js';
import { initCustomCursor } from './cursor.js';
import { MusicPlayer } from './player.js';
import { initCountdown } from './countdown.js';
import { RandomMessages } from './messages.js';
import { initScrollReveal, initScrollProgressBar } from './scrollreveal.js';
import { initModal } from './modal.js';
import { initGallery } from './gallery.js';
import { initTimeline } from './timeline.js';

document.addEventListener('DOMContentLoaded', () => {
  // --- Fondo espacial y ambientación visual ---
  initStarfield('space-canvas');
  initPetals('petals-canvas');
  initCustomCursor();

  // --- Navegación y progreso de scroll ---
  initScrollProgressBar('scroll-progress');
  initScrollReveal();

  // --- Cuenta regresiva ---
  initCountdown('countdown');

  // --- Galería y línea del tiempo (vacías en Fase 1) ---
  initGallery('gallery-grid', 'data/galeria.json');
  initTimeline('timeline-list', 'data/timeline.json');

  // --- Reproductor de música (persiste durante toda la navegación) ---
  const player = new MusicPlayer({
    dataUrl: 'data/playlist.json',
    rootId: 'music-player',
    playlistListId: 'playlist-list',
  });
  player.init();

  // --- Mensajes aleatorios ---
  const randomMessages = new RandomMessages({
    dataUrl: 'data/messages.json',
    buttonId: 'random-message-btn',
    cardId: 'message-card',
  });
  randomMessages.init();

  // --- Modal "Ábreme cuando me extrañes" ---
  initModal({ triggerId: 'miss-you-btn', overlayId: 'miss-you-modal' });

  // --- Pantalla de bienvenida ---
  const welcomeScreen = document.getElementById('welcome-screen');
  const startBtn = document.getElementById('start-journey-btn');
  startBtn?.addEventListener('click', () => {
    welcomeScreen.classList.add('is-hidden');
    // Intenta iniciar la música justo tras la primera interacción del usuario
    player.play();
    document.getElementById('hero')?.scrollIntoView({ behavior: 'smooth' });
  });

  // --- Efecto de escritura del subtítulo del hero (si Typed.js está disponible) ---
  const typedTarget = document.getElementById('hero-typed');
  if (typedTarget && window.Typed) {
    new window.Typed('#hero-typed', {
      strings: [
        'Un pequeño universo, construido con cuidado.',
        'Cada estrella tiene su lugar aquí.',
        'Bienvenido a este rincón del cosmos.',
      ],
      typeSpeed: 40,
      backSpeed: 20,
      backDelay: 2200,
      loop: true,
      smartBackspace: true,
    });
  }

  // --- AOS (Animate On Scroll), si está disponible ---
  if (window.AOS) {
    window.AOS.init({ duration: 800, once: true, offset: 60 });
  }
});
