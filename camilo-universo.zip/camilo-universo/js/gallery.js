/* ============================================================
   GALLERY — renderiza fotos desde data/galeria.json
   ============================================================ */

export async function initGallery(gridId = 'gallery-grid', dataUrl = 'data/galeria.json') {
  const grid = document.getElementById(gridId);
  if (!grid) return;

  let fotos = [];
  try {
    const res = await fetch(dataUrl);
    const data = await res.json();
    fotos = data.fotos || [];
  } catch (err) {
    console.error('No se pudo cargar galeria.json', err);
  }

  if (fotos.length === 0) {
    grid.innerHTML = '<p class="placeholder-note">Aún no hay fotografías. Agrégalas en <code>assets/images/galeria/</code> y regístralas en <code>data/galeria.json</code>.</p>';
    return;
  }

  grid.innerHTML = fotos.map(foto => `
    <figure class="gallery-item" data-reveal="zoom">
      <img src="${foto.src}" alt="${(foto.caption || '').replace(/"/g, '&quot;')}" loading="lazy">
    </figure>
  `).join('');
}
