# Camilo ❤️ — Un universo digital (Fase 1)

Base funcional completa de la página. **Sin contenido sentimental todavía** —
esta fase construye toda la infraestructura técnica y visual. El texto de
"Nuestra Historia", "Cartas para Ti" y el mensaje final se agregará en las
siguientes fases.

## Cómo verla

Abre `index.html` con un servidor local (no funciona con doble clic directo
por las restricciones de `fetch` en `file://`). Opciones sencillas:

```bash
# Con Python
python3 -m http.server 8000

# Con Node
npx serve .
```

Luego visita `http://localhost:8000`.

## Estructura del proyecto

```
camilo-universo/
├── index.html              → documento principal, todas las secciones
├── css/
│   ├── variables.css       → paleta, tipografía, espaciado (tokens)
│   ├── base.css             → reset y fundamentos
│   ├── components.css       → botones, cursor, reproductor, modal, glass
│   ├── sections.css         → layout de cada sección
│   └── animations.css       → keyframes y scroll reveal
├── js/
│   ├── main.js               → orquestador, punto de entrada
│   ├── starfield.js           → fondo espacial (estrellas, nebulosas, fugaces)
│   ├── petals.js               → lluvia de pétalos morados
│   ├── cursor.js                → cursor personalizado
│   ├── player.js                 → reproductor de música completo
│   ├── countdown.js               → cuenta regresiva
│   ├── messages.js                 → mensajes aleatorios
│   ├── gallery.js                   → galería (lee data/galeria.json)
│   ├── timeline.js                   → línea del tiempo (lee data/timeline.json)
│   ├── modal.js                       → modal genérico reutilizable
│   └── scrollreveal.js                 → scroll reveal + barra de progreso
├── data/
│   ├── playlist.json         → canciones del reproductor
│   ├── messages.json          → mensajes aleatorios
│   ├── timeline.json           → hitos de la línea del tiempo (vacío)
│   └── galeria.json             → fotografías (vacío)
└── assets/
    ├── music/                 → coloca aquí tus MP3/WAV/OGG
    ├── images/galeria/          → coloca aquí tus fotografías
    └── img/                       → recursos visuales propios (portada default)
```

## Cómo agregar música

1. Copia tus archivos `.mp3`, `.wav` u `.ogg` dentro de `assets/music/`.
2. Agrega una entrada por canción en `data/playlist.json`:
   ```json
   {
     "titulo": "Nombre de la canción",
     "artista": "Nombre del artista",
     "src": "assets/music/archivo.mp3",
     "cover": "assets/img/portada-default.svg"
   }
   ```
3. Recarga la página. Aparecerá en "Nuestra Playlist ❤️" automáticamente.

**Importante:** no se incluye ninguna canción protegida por derechos de autor.
El reproductor está listo para tus propios archivos descargados legalmente.

## Cómo agregar fotografías

Copia las imágenes en `assets/images/galeria/` y registra cada una en
`data/galeria.json` (ver instrucciones dentro de ese archivo).

## Qué está funcional en esta fase

- ✅ Pantalla de bienvenida con botón "Comenzar nuestro viaje"
- ✅ Fondo espacial animado: estrellas con parallax, nebulosas, estrellas fugaces, constelación decorativa
- ✅ Lluvia de pétalos morados
- ✅ Cursor personalizado con estado hover
- ✅ Glassmorphism, glow y blur en toda la interfaz
- ✅ Reproductor de música completo (play/pausa, siguiente/anterior, progreso,
  tiempo, volumen, aleatorio, repetición, portada, título, artista) — la
  música sigue sonando mientras navegas
- ✅ Sección "Nuestra Playlist ❤️" generada dinámicamente desde `playlist.json`
- ✅ Cuenta regresiva en vivo del 5 de julio de 2025 al 4 de julio de 2026
- ✅ Galería preparada (vacía, lista para fotos)
- ✅ Línea del tiempo interactiva preparada (vacía, lista para hitos)
- ✅ Botón "Ábreme cuando me extrañes ❤️" con modal funcional (contenido pendiente)
- ✅ Sistema de mensajes aleatorios vía JSON (con mensajes de ejemplo)
- ✅ Secciones preparadas y vacías: "Nuestra Historia", "Cartas para Ti ❤️",
  mensaje final "TE AMO 3 MILLONES ❤️"
- ✅ Scroll reveal (fade / zoom), barra de progreso de scroll, responsive completo

## Próximos pasos

- **Fase 2:** contenido emocional — "Nuestra Historia", hitos de la línea del
  tiempo, mensajes aleatorios reales, contenido del botón "Ábreme cuando me
  extrañes ❤️".
- **Fase 3:** "Cartas para Ti ❤️" y el mensaje final "TE AMO 3 MILLONES ❤️".

Avísame cuando quieras continuar con la Fase 2.
